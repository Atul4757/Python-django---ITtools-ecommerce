from django.contrib import admin

# Register your models here.
from .models import Product
from .models import Shopping_cart
from .models import order_detail
from .models import biling_detail
from .models import contact
from .models import category
admin.site.register(Product)
admin.site.register(Shopping_cart)
admin.site.register(order_detail)
admin.site.register(contact)
admin.site.register(category)
admin.site.register(biling_detail)

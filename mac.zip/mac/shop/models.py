from django.db import models
from django.conf import settings
from django.urls import reverse



# Create your models here.


class category(models.Model):
    id = models.AutoField(primary_key=True)
    cat_name = models.CharField(max_length=50, default="")

    def __str__(self):
        return self.cat_name

    def get_all_category():
        return category.objects.all()




class Product(models.Model):
    Product_name = models.CharField(max_length=100)
    price = models.CharField(max_length=50, default="0")
    saveprice = models.CharField(max_length=50, default="0",  blank=True)
    description = models.CharField(max_length=1000)
    Category = models.ForeignKey(category, default="", on_delete=models.CASCADE)
    Subcategory = models.CharField(max_length=50, default="")
    pub_date = models.DateField()
    image1 = models.ImageField(upload_to="product", default="")
    image2 = models.ImageField(upload_to="product", default="", blank=True)
    image3 = models.ImageField(upload_to="product", default="", blank=True)

    def __str__(self):
        return self.Product_name

    def get_all_product():
        return Product.objects.all()

    def get_shopping_cart_url(self):
        return reverse("core: Shopping_cart", kwargs={'id': self.id})

    def get_category_id( category_id):
        if category_id:
            return Product.objects.filter(Category=category_id)
        else:
            return Product.get_all_product()


class Shopping_cart(models.Model):
    id = models.AutoField
    product = models.ForeignKey(Product, default="", on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)


    def __str__(self):
        return f"{self.quantity} of {self.product.Category}"

    def get_total_item_price(self):
        total = float(self.quantity) * float(self.product.price)
        return total

class order_detail(models.Model):
    id = models.AutoField
    user = models.ForeignKey(settings.AUTH_USER_MODEL, default="", on_delete=models.CASCADE)
    items = models.ManyToManyField(Shopping_cart)
    start_date = models.DateField(auto_now_add=True)
    order_date = models.DateField()
    ordered = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user} of {self.start_date}"

    def subtotal(self):
        total = 0
        for order_item in self.items.all():
            total += order_item.get_total_item_price()
        return float(total)


class user(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    Confrim_password = models.CharField(max_length=50)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    Gender = models.CharField(max_length=50)
    Address = models.CharField(max_length=300)
    City = models.CharField(max_length=50)
    State = models.CharField(max_length=50)
    Pin_code = models.BigIntegerField
    Contact_no = models.BigIntegerField
    Email_Id = models.CharField(max_length=50)

    def __str__(self):
        return self.username

class contact(models.Model):
    msg_name = models.CharField(max_length=50)
    msg_email = models.CharField(max_length=50)
    msg_message = models.CharField(max_length=5000)
    msg_subject = models.CharField(max_length=50)

    def __str__(self):
        return self.msg_name

class biling_detail(models.Model):
    order_detal = models.ManyToManyField(order_detail)
    first_name = models.CharField(max_length=50, default="")
    last_name = models.CharField(max_length=50, default="")
    phonenumbe = models.CharField(max_length=50, default="")
    email = models.CharField(max_length=50, default="")
    address = models.CharField(max_length=50,default="")
    city = models.CharField(max_length=50, default="")
    country = models.CharField(max_length=50, default="")
    zip = models.CharField(max_length=50, default="")


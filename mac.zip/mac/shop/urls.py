from django.urls import path
from django.conf.urls import url, include
from django.contrib.auth import views as auth_views

from . import views
urlpatterns = [

    path('password_changeView/', auth_views.PasswordChangeView.as_view(), name='password_change'),

    path('password_changeView/done', auth_views.PasswordChangeDoneView.as_view(), name='password_change'),

    path('reset_password/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('reset_password/done', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset_password/confirm/<uidb64>[0-9A-Za-z]+)-<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset_password/complete/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    path('accounts/login/', views.Login, name='login'),
    path("", views.index, name="shopHome"),
    path('cart/', views.cart.as_view(), name='cart'),
    path('message', views.message, name='message'),
    path('register', views.register, name='register'),
    path('signup', views.signup, name='signup'),
    path('Login', views.Login, name='Login'),
    path('Logout', views.Logout,  name='Logout'),
    #url(r'^categoria/(?P<pk>[0..9]+)/$', views.CategoriaDetail.as_view(), name='cat'),
    path('checkout/', views.checkout.as_view(),  name='checkout'),
    path('confirmation/', views.confirmation.as_view(),  name='confirmation'),
    path("shopping_cart/<int:id>/", views.shopping_cart, name='shopping_cart'),
    path("delete/<int:id>", views.delete, name='delete'),
    path("change/<int:id>", views.change_qty, name='change'),
    path("search", views.search, name='search'),
    path("product_detail/<int:id>", views.product_detail, name='product_detail'),
  #  path("catprod", views.catprod, name='catprod'),
    path("user_detail", views.user_detail, name='user_detail')


    # url(r'^paypal/', include('paypal.standard.ipn.urls')),
##
]



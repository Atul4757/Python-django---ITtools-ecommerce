from django.shortcuts import render, redirect, HttpResponse, get_object_or_404
from .models import Product, contact, Shopping_cart, order_detail, category, biling_detail
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.models import User
from django.contrib import messages
from django.utils import timezone
from django.contrib.auth import authenticate, login, logout
from django.views.generic import View

from django.core.exceptions import ObjectDoesNotExist
from django.core.mail import send_mail





def index(request):
    categories = category.objects.all()
    categoryID = request.GET.get('category')
    if categoryID:
        object_list = Product.get_category_id(categoryID)
    else:
        object_list = Product.get_all_product()
    page = request.GET.get('page', 1)
    paginator = Paginator(object_list, 12)
    try:
        object_list = paginator.page(page)
    except PageNotAnInteger:
        object_list = paginator.page(1)
    except EmptyPage:
        object_list = paginator.page(paginator.num_pages)
    params = {'Product': object_list, 'category': categories}
    return render(request, 'shop/index.html', params)


def search(request):
    query = request.GET['query']
    search_product = None
    if Product.objects.filter(Product_name__icontains=query):
        search_product = Product.objects.filter(Product_name__icontains=query)
    elif category.objects.filter(cat_name__icontains=query):
        search_product = category.objects.filter(cat_name__icontains=query)

    context = {'Product': search_product}
    return render(request, "shop/index.html", context)

def register(request):
    return render(request, "shop/register.html")


def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        password = request.POST['password']
        conpassword = request.POST['conpassword']
        # validation
        if password != conpassword:
            messages.error(request, "password & confirm password not match")
            return redirect('register')
        else:
            shop_user = User.objects.create_user(username, email, password)
            shop_user.first_name = fname
            shop_user.last_name = lname
            shop_user.save()
            messages.success(request, 'account created')
            return render(request, 'shop/login.html')
    else:
        return HttpResponse('not found')


def Login(request):
    if request.method == 'POST':
        loginusername = request.POST['lusername']
        loginpassword = request.POST['loginpass']

        user = authenticate(username=loginusername, password=loginpassword)

        if user is not None:
            login(request, user)
            messages.success(request, "loging succesfull")
            return redirect('shopHome')
        else:
            messages.error(request, "not valid password or username")
            return redirect('Login')
    return render(request, 'shop/login.html')


def Logout(request):
        logout(request)
        messages.success(request, "successfull logout")
        return redirect("shopHome")

def product_detail(request, id):
    product = Product.objects.filter(id=id)
    return render(request, 'shop/product_detail.html', {'Product': product[0]})



class cart(View):
        def get(self, *args, **kwargs):
            if self.request.user.is_authenticated:
                try:
                    order = order_detail.objects.get(user=self.request.user, ordered=False)
                    context = {
                        'object': order
                    }
                    return render(self.request, 'shop/cart.html', context)
                except ObjectDoesNotExist:
                    messages.error(self.request, "you are not have an active order")
                    return redirect("/")
            else:
                return redirect("/Login")


def shopping_cart(request, id):
    if request.user.is_authenticated:
        product = get_object_or_404(Product, id=id)
        cart_item, created = Shopping_cart.objects.get_or_create(product=product)
        orderdetail_qs = order_detail.objects.filter(user=request.user, ordered=False)
        if orderdetail_qs.exists():
            orderdetail = orderdetail_qs[0]
            # check if cart_item in order_detail
            if orderdetail.items.filter(product__id=product.id).exists():
                messages.info(request, "this item added")
                cart_item.quantity += 1
                cart_item.save()
            else:
                orderdetail.items.add(cart_item)
        else:
             order_date = timezone.now()
             orderdetail = order_detail.objects.create(user=request.user, order_date=order_date)
             orderdetail.items.add(cart_item)
             return redirect("/cart", id=id)
    else:
        return redirect("/Login")
    return redirect("/cart")


def delete(request, id):
    product = get_object_or_404(Product, id=id)
    orderdetail_qs = order_detail.objects.filter(user=request.user, ordered=False)

    if orderdetail_qs.exists():
        messages.info(request, "hello")
        orderdetail = orderdetail_qs[0]
        if orderdetail.items.filter(product__id=id).exists():
            cart_item = Shopping_cart.objects.filter(product=product)[0]
            orderdetail.items.remove(cart_item)
            messages.info(request, "this item was removed")
            return redirect("/cart")
        else:
            messages.info(request, "this item was not match")
    else:
        return redirect("/cart")
    return redirect("/cart")



def change_qty(request, id):
    product = get_object_or_404(Product, id=id)
    orderdetail_qs = order_detail.objects.filter(user=request.user, ordered=False)

    if orderdetail_qs.exists():
        orderdetail = orderdetail_qs[0]
        if orderdetail.items.filter(product__id=id).exists():
          cart_item = Shopping_cart.objects.filter(product=product)[0]
          if cart_item.quantity > 1:
              cart_item.quantity -= 1
              cart_item.save()
          else:
              orderdetail.items.remove(cart_item)
          return redirect("/cart")
        else:
            messages.info(request, "this item was not match")
    else:
        return redirect("/cart")
    return redirect("/cart")


def user_detail(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            messages.error(request, "get")
            first_name = request.POST.get('first')
            last_name = request.POST.get('last')
            phonenumber = request.POST.get('phonenumber')
            email = request.POST.get('email')
            address = request.POST.get('address')
            city = request.POST.get('city')
            country = request.POST.get('country')
            zip = request.POST.get('zip')
            checkout = biling_detail(first_name=first_name, last_name=last_name, phonenumbe=phonenumber,
                                     email=email, address=address, city=city, country=country, zip=zip)
            checkout.save()
            messages.success(request, 'your order submited')

            return redirect("/confirmation")
    else:
        return render(request, "/login")



class checkout(View):
    def get(self, *args, **kwargs):

        if self.request.user.is_authenticated:

            try:

                order = order_detail.objects.get(user=self.request.user, ordered=False)
                context = {'object': order}

                return render(self.request, 'shop/checkout.html', context)
            except ObjectDoesNotExist:
                messages.error(self.request, "you are not have an active order")
                return redirect("/")

        else:
            return render(self.request, 'shop/index.html')



class confirmation(View):

    def get(self, *args, **kwargs):
        if self.request.user.is_authenticated:
            send_mail(
                'new order',
                'have new order',
                'atul.hamirani4@gmail.com',
                ['atul.hamirani7@gmail.com'],
                fail_silently=False,
            )
            try:
                order = order_detail.objects.get(user=self.request.user, ordered=False)
                context = {
                    'object': order
                }

                return render(self.request, 'shop/confirmation.html', context)
            except ObjectDoesNotExist:
                messages.error(self.request, "you are not have an active order")
                return redirect("/")
        else:
            return redirect("/Login")

def message(request):
    if request.method == "POST":
        msg_name = request.POST.get('msg_name')
        msg_email = request.POST.get('msg_email')
        msg_subject = request.POST.get('msg_subject')
        msg_message = request.POST.get('msg_message')
        message = contact(msg_name=msg_name, msg_email=msg_email, msg_message=msg_message, msg_subject=msg_subject)
        message.save()
        messages.success(request, 'Message submited')
    return render(request, 'shop/contact.html')
